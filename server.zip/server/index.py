import asyncio
import aiohttp
import random
import time
import json
import base64
import requests
import os
import configparser

def main_handler(event, context):
    method=event["search"]['method']
    url=event["search"]['url']
    speed=event["search"]['speed']
    dict=event["search"]['dict']
    request_id=context["request_id"]
    search_task=Search(url,dict,method,int(speed))
    Ret_Meg=search_task.run()
    gitee_sender=Gitee(request_id,Ret_Meg)
    res=gitee_sender.push()
    return res

class Search():
    
    def __init__(self,url,dir,method,speed):
        self.res = {"result200": [], "result300": [], "result400": [], "result500": [], "result_other": []}
        self.dir_list = dir
        self.users_agents = []
        self.url=url
        self.method=method
        self.speed=speed     #50
        with open("headers.txt", "r", encoding="utf-8") as f:
            tmp = f.readlines()
            for items in tmp:
                self.users_agents.append(items.replace("\n", ""))
        pass

    def __send_result(self, dict):
        if(dict["status_code"]>=200 and dict["status_code"]<300 ):
            self.res["result200"].append(dict)
        elif(dict["status_code"]>=300 and dict["status_code"]<400):
            self.res["result300"].append(dict)
        elif (dict["status_code"]!=404 and dict["status_code"]<500 and dict["status_code"]>=400):
            self.res["result400"].append(dict)
        elif (dict["status_code"]>=500 and dict["status_code"]<600):
            self.res["result500"].append(dict)
        else:
            if dict["status_code"]!=404:
                self.res["result_other"].append(dict)
    def __send_error(self, url):
        self.res["result_other"].append(url)



    async  def __fetch(self,url2):
        async with self.sem:  #100
            header=self.users_agents[random.randrange(1,153)]
            header={"User-Agent":header}
            async  with aiohttp.ClientSession(headers=header) as session:
                if(self.method=="get"):
                    try:
                        async  with session.get(url2) as res:
                            respond_text=await res.text()
                            respond_len=len(respond_text)
                            status_code=res.status
                            return_value={"status_code":status_code,"length": respond_len,"url":url2}
                            self.__send_result(return_value)
                            ##
                            # dir=url2.replace(self.url,"")
                            # l=len(self.dir_list)
                            # if self.dir_list.index(dir)==l//10:
                            #     print("10%")
                            # elif self.dir_list.index(dir)==l//5:
                            #     print("20%")
                            # elif self.dir_list.index(dir)==3*l//10:
                            #     print("30%")
                            # elif self.dir_list.index(dir)==4*l//10:
                            #     print("40%")
                            # elif self.dir_list.index(dir) == l//2:
                            #     print("50%")
                            # elif self.dir_list.index(dir) == 3*l//5:
                            #     print("60%")
                            # elif self.dir_list.index(dir) == 7*l//10:
                            #     print("70%")
                            # elif self.dir_list.index(dir) == 4*l//5:
                            #     print("80%")
                            # elif self.dir_list.index(dir) == 9*l//10:
                            #     print("90%")
                            # elif self.dir_list.index(dir) == 95*l//100:
                            #     print("95%")

                            # print(return_value)
                    except:
                        self.__send_error(url2)
                elif self.method== "head":
                    try:
                        async  with session.head(url2) as res:
                            status_code=res.status
                            return_value={"status_code":status_code, "length": "-","url": url2}

                            self.__send_result(return_value)
                    except:
                        self.__send_error(url2)
                else:
                    return "Method Error"


    async def __start(self):
        tasks=[]
        self.sem = asyncio.Semaphore(self.speed)
        for i in self.dir_list:
            if self.url[-1]=="/":
                scan_url=self.url+i
            else:
                scan_url=self.url+"/"+i
            tasks.append(asyncio.get_event_loop().create_task(self.__fetch(scan_url)))
        await  asyncio.gather(*tasks)


    def run(self):
        loop=asyncio.get_event_loop()
        task=loop.create_task(self.__start())
        loop.run_until_complete(task)
        return self.res


class Gitee():

    def __init__(self,request_id,msg):
        self.msg=self.__base64(json.dumps(msg))
        self.id=request_id
        self.__get_config()

    def __base64(self,msg):
        msg=msg.encode('utf-8')
        tmp=base64.b64encode(msg)
        data=tmp.decode('utf-8')
        return data
    def __get_config(self):
        file_path = os.path.join(os.path.abspath('.'), 'server.ini')
        if not os.path.exists(file_path):
            return 0
        reader=configparser.ConfigParser()
        reader.read(file_path)
        self.access_token=reader.get("Gitee","access_token")
        self.owner=reader.get("Gitee","owner")
        self.repo=reader.get("Gitee","repo")

        pass
    def push(self):
        send_text=self.__base64(self.msg)
        data_send = {"access_token": self.access_token,"content": send_text, "message": "Return Msg Of Poorscanner Server"}
        a = requests.post("https://gitee.com/api/v5/repos/maple_10101/mapletest/contents/"+self.id,data=data_send)
        print(self.access_token,self.id)
        print(a)
        info=json.loads(a.text)
        url=info['content']['download_url']
        print(url)
        return url